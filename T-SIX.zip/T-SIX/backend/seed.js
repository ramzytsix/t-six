require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const connectDB = require('./config/db');

async function seedAdmin() {
  await connectDB();
  const { ADMIN_USERNAME, ADMIN_PASSWORD } = process.env;

  const existing = await User.findOne({ username: ADMIN_USERNAME });
  if (existing) {
    console.log('✅ User admin already exists. Skipping.');
    process.exit(0);
  }

  const hashed = await bcrypt.hash(ADMIN_PASSWORD, 10);
  await User.create({ username: ADMIN_USERNAME, password: hashed });
  console.log(`🔥 Admin user "${ADMIN_USERNAME}" created successfully!`);
  process.exit(0);
}

seedAdmin();