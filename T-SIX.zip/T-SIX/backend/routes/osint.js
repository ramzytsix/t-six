const express = require('express');
const axios = require('axios');
const qrcode = require('qrcode');
const whois = require('whois');
const { parsePhoneNumber } = require('libphonenumber-js');
const auth = require('../middlewares/auth');

const router = express.Router();

// QR Generator (publik)
router.post('/qr', async (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'Text required' });
  try {
    const qr = await qrcode.toDataURL(text);
    res.json({ qr });
  } catch { res.status(500).json({ error: 'QR generation failed' }); }
});

// --- OSINT (Hanya login) ---

// IP Lookup
router.get('/ip/:target', auth, async (req, res) => {
  const ip = req.params.target;
  try {
    const geo = await axios.get(`http://ip-api.com/json/${ip}?fields=status,country,regionName,city,isp,org,lat,lon,timezone,query`);
    if (geo.data.status !== 'success') throw new Error('Invalid IP');
    res.json({ success: true, data: geo.data });
  } catch (e) {
    res.status(400).json({ error: 'IP tidak valid atau error' });
  }
});

// Email Check (HIBP - anonymized)
router.get('/email/:target', auth, async (req, res) => {
  const email = req.params.target;
  try {
    // HIBP v3 requires hash prefix, but we'll use simple regex validation + dummy data for demo
    // For real, use HIBP API with hash. Here we return a placeholder.
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!valid) throw new Error('Invalid email');
    res.json({ success: true, data: { email, breach_status: 'Not checked (use real API key)' } });
  } catch (e) {
    res.status(400).json({ error: 'Email tidak valid' });
  }
});

// Username Search (Cross-platform)
router.get('/username/:target', auth, async (req, res) => {
  const username = req.params.target;
  const platforms = ['github.com', 'twitter.com', 'instagram.com', 'youtube.com', 'reddit.com'];
  const results = [];
  for (const platform of platforms) {
    try {
      const url = `https://${platform}/${username}`;
      const resp = await axios.head(url, { timeout: 2000 });
      results.push({ platform, url, exists: resp.status === 200 });
    } catch {
      results.push({ platform, url: `https://${platform}/${username}`, exists: false });
    }
  }
  res.json({ success: true, data: results });
});

// Domain WHOIS
router.get('/domain/:target', auth, (req, res) => {
  const domain = req.params.target;
  whois.lookup(domain, (err, data) => {
    if (err) return res.status(400).json({ error: 'WHOIS lookup failed' });
    res.json({ success: true, data: data });
  });
});

// Phone Number Info
router.get('/phone/:target', auth, (req, res) => {
  const phone = req.params.target;
  try {
    const parsed = parsePhoneNumber(phone, 'ID');
    if (!parsed || !parsed.isValid()) throw new Error('Invalid phone');
    res.json({ success: true, data: { country: parsed.country, carrier: parsed.carrier, format: parsed.formatInternational() } });
  } catch (e) {
    res.status(400).json({ error: 'Nomor tidak valid' });
  }
});

module.exports = router;