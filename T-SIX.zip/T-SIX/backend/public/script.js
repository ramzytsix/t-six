const API = '/api';
let token = localStorage.getItem('tsix_token');

if (token) showDashboard();

function showLogin() {
  document.getElementById('homeGuest').style.display='none';
  document.getElementById('loginPage').style.display='block';
  document.getElementById('dashboard').style.display='none';
}
function showDashboard() {
  document.getElementById('homeGuest').style.display='none';
  document.getElementById('loginPage').style.display='none';
  document.getElementById('dashboard').style.display='block';
  document.getElementById('authBtn').innerText = 'Logout';
  document.getElementById('authBtn').onclick = handleLogout;
  fetch(API+'/auth/me', { headers: { 'Authorization': 'Bearer '+token } })
    .then(r => r.json())
    .then(d => document.getElementById('userDisplay').innerText = d.username);
}

async function handleLogin() {
  const u = document.getElementById('loginUser').value;
  const p = document.getElementById('loginPass').value;
  const res = await fetch(API+'/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: u, password: p })
  });
  const data = await res.json();
  if (data.success) {
    token = data.token; localStorage.setItem('tsix_token', token);
    showDashboard();
  } else {
    document.getElementById('loginError').innerText = data.error || 'Login gagal';
  }
}

function handleLogout() { localStorage.removeItem('tsix_token'); token = null; location.reload(); }

document.getElementById('authBtn').addEventListener('click', () => {
  if (token) handleLogout();
  else showLogin();
});

// QR Generator
async function generateQR() {
  const text = document.getElementById('qrInput').value;
  if (!text) return alert('Masukkan teks');
  const res = await fetch(API+'/osint/qr', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text })
  });
  const d = await res.json();
  if (d.qr) document.getElementById('qrResult').innerHTML = `<img src="${d.qr}" />`;
}

// Downloader
async function downloadYT() {
  const url = document.getElementById('dlInput').value;
  const format = document.getElementById('dlFormat').value;
  if (!url) return alert('Masukkan link YouTube');
  const res = await fetch(API+'/download/yt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url, format })
  });
  const d = await res.json();
  if (d.success) {
    document.getElementById('dlResult').innerHTML = `
      <p><strong>${d.title}</strong> (${d.duration}s)</p>
      <p>Thumbnail: <img src="${d.thumbnail}" style="max-width:200px;" /></p>
      <p>Download via: <a href="${d.downloadUrl}" target="_blank">${d.downloadUrl}</a></p>
    `;
  } else {
    document.getElementById('dlResult').innerHTML = `<p class="error-msg">${d.error}</p>`;
  }
}

// OSINT
async function runOSINT(type) {
  if (!token) return alert('Login dulu bang!');
  let inputMap = { ip: 'osintIP', email: 'osintEmail', username: 'osintUser', domain: 'osintDomain', phone: 'osintPhone' };
  let resultMap = { ip: 'resultIP', email: 'resultEmail', username: 'resultUser', domain: 'resultDomain', phone: 'resultPhone' };
  const target = document.getElementById(inputMap[type]).value;
  if (!target) return alert('Masukkan target');

  const res = await fetch(API+`/osint/${type}/${encodeURIComponent(target)}`, {
    headers: { 'Authorization': 'Bearer '+token }
  });
  const d = await res.json();
  const el = document.getElementById(resultMap[type]);
  if (d.success) {
    el.innerHTML = `<pre>${JSON.stringify(d.data, null, 2)}</pre>`;
  } else {
    el.innerHTML = `<p class="error-msg">${d.error || 'Error'}</p>`;
  }
}